Shah Tunnel universal Linux binary bundle
Version: 1.6.3
Architectures: linux/amd64 and linux/arm64

This archive contains both prebuilt binaries. No Go compiler, source build,
GitHub Actions workflow, or GitHub-side compilation is required.

After extracting as root, run:
  ./install.sh

Optional destination:
  ./install.sh /usr/local/bin/ravanreverse

The installer selects the correct binary from uname -m and verifies both
binary checksums before installing.
