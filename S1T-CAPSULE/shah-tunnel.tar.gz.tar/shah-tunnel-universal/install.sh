#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
DEST="${1:-/usr/local/bin/ravanreverse}"
[[ "$(uname -s)" == Linux ]] || { echo "Shah Tunnel supports Linux only." >&2; exit 1; }
case "$(uname -m)" in
  x86_64|amd64) BIN="$ROOT/bin/linux-amd64/ravanreverse" ;;
  aarch64|arm64) BIN="$ROOT/bin/linux-arm64/ravanreverse" ;;
  *) echo "Unsupported architecture: $(uname -m)" >&2; exit 1 ;;
esac
command -v install >/dev/null 2>&1 || { echo "install command is required." >&2; exit 1; }
command -v sha256sum >/dev/null 2>&1 || { echo "sha256sum is required." >&2; exit 1; }
(cd "$ROOT" && sha256sum -c SHA256SUMS >/dev/null)
install -D -o root -g root -m 0750 "$BIN" "$DEST"
echo "Installed $(uname -m) Shah Tunnel binary to: $DEST"
"$DEST" version
